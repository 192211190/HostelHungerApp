<?php
// Include the database configuration file
include('config.php');

// Prepare the response array
$response = array();

// Query to fetch data from the "items" table
$sql = "SELECT * FROM items";
$result = $conn->query($sql);

// Check if there are any rows returned
if ($result->num_rows > 0) {
    // Fetch the data into an array
    $items = array();
    while ($row = $result->fetch_assoc()) {
        // Add each row to the items array
        $items[] = $row;
    }

    // Set the response status and data
    $response['status'] = 'success';
    $response['data'] = $items;
} else {
    // If no data is found
    $response['status'] = 'error';
    $response['message'] = 'No records found.';
}

// Close the connection
$conn->close();

// Return the response as JSON
echo json_encode($response);
?>
