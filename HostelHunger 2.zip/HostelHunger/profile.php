<?php
// Include the database configuration
require 'config.php';

// Initialize response array
$response = [
    "status" => "error",
    "message" => "No data found.",
    "data" => []
];

// Fetch data from the 'profile' table
try {
    // Prepare the query to fetch 'id', 'name', 'location' from the 'profile' table
    $stmt = $conn->prepare("SELECT id, name, location FROM profile");
    
    // Execute the query
    $stmt->execute();

    // Store the result
    $result = $stmt->get_result();

    // Check if any rows are returned
    if ($result->num_rows > 0) {
        // Fetch all data
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                'id' => $row['id'],
                'name' => $row['name'],
                'location' => $row['location']
            ];
        }

        // Prepare the success response
        $response["status"] = "success";
        $response["message"] = "Data fetched successfully.";
        $response["data"] = $data;
    } else {
        throw new Exception("No records found.");
    }

    // Close the statement
    $stmt->close();
} catch (Exception $e) {
    // In case of error, set the error message in the response
    $response["message"] = $e->getMessage();
}

// Close the database connection
$conn->close();

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response, JSON_PRETTY_PRINT);
?>
