<?php
// Include the database configuration file
include('config.php');

// Prepare the response array
$response = array();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the POST request has the 'food_name' and 'amount' fields
    if (isset($_POST['food_name']) && isset($_POST['amount'])) {
        // Get the food_name and amount data
        $food_name = $_POST['food_name'] ?: '';  // Set to empty string if not provided
        $amount = $_POST['amount'] ?: '';       // Set to empty string if not provided

        // Check if the connection is successful
        if ($conn->connect_error) {
            echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
            exit();
        }

        // Escape the food_name and amount values to prevent SQL injection
        $food_name = $conn->real_escape_string($food_name);
        $amount = $conn->real_escape_string($amount);

        // Prepare the SQL query to insert the data into the `items` table
        $sql = "INSERT INTO items (food_name, amount) VALUES ('$food_name', '$amount')";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            // Success response
            $response = [
                "status" => "success",
                "message" => "Data added successfully.",
                "data" => [
                    [
                        "food_name" => $food_name,
                        "amount" => $amount
                    ]
                ]
            ];
        } else {
            $response = [
                "status" => "error",
                "message" => "Error inserting data: " . $conn->error
            ];
        }

        // Close the database connection
        $conn->close();
    } else {
        // If food_name or amount fields are missing
        $response = [
            "status" => "error",
            "message" => "Please provide food_name and amount."
        ];
    }
} else {
    // If the request method is not POST
    $response = [
        "status" => "error",
        "message" => "Invalid request method. Please use POST."
    ];
}

// Return the response as JSON
echo json_encode($response);
?>
