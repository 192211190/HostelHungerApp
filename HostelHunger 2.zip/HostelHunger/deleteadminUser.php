<?php
// Include the database configuration file
include('config.php');

// Prepare the response array
$response = array();

// Check if the connection is successful
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Check if the 'id' is provided in the POST request
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Escape the 'id' to prevent SQL injection
    $id = $conn->real_escape_string($id);

    // Query to delete the user from the `adminUsers` table based on the provided id
    $sql = "DELETE FROM adminUsers WHERE id = $id";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // If the deletion was successful
        $response['status'] = 'success';
        $response['message'] = 'User deleted successfully.';
    } else {
        // If there was an error during the deletion
        $response['status'] = 'error';
        $response['message'] = 'Error deleting user: ' . $conn->error;
    }
} else {
    // If no 'id' is provided in the request
    $response['status'] = 'error';
    $response['message'] = 'No user id provided.';
}

// Close the connection
$conn->close();

// Return the response as JSON
echo json_encode($response);
?>
