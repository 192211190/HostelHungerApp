<?php
// Include the database configuration file
include('config.php');

// Check if the form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the POST request
    $item_id = $_POST['id'];   // Item ID from the table (make sure it's sent)
    $comment = $_POST['comments'];    // Comment from the user
    $rating = $_POST['rating'];     // Rating from the user

    // Check if all fields are filled
    if (!empty($item_id) && !empty($comment) && !empty($rating)) {
        // Prepare an SQL query to insert the data
        $sql = "UPDATE items SET comments = ?, rating = ? WHERE id = ?";

        // Prepare the statement
        if ($stmt = $conn->prepare($sql)) {
            // Bind parameters to the query
            $stmt->bind_param("sdi", $comment, $rating, $item_id);

            // Execute the query
            if ($stmt->execute()) {
                // Success response
                $response = array("status" => "success", "message" => "Comment and rating added successfully.");
            } else {
                // Error executing query
                $response = array("status" => "error", "message" => "Failed to add comment and rating.");
            }

            // Close the statement
            $stmt->close();
        } else {
            // Error preparing the query
            $response = array("status" => "error", "message" => "Failed to prepare the SQL statement.");
        }
    } else {
        // Missing fields in the request
        $response = array("status" => "error", "message" => "Please fill in all fields.");
    }
} else {
    // Invalid request method
    $response = array("status" => "error", "message" => "Invalid request method.");
}

// Close the connection
$conn->close();

// Return the response as JSON
echo json_encode($response);
?>
