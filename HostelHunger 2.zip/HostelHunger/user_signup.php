<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file
include 'config.php';

$RequestMethod = $_SERVER["REQUEST_METHOD"];

if ($RequestMethod == "POST") {
    try {
        // Validate required fields
        if (!isset($_POST['username'], $_POST['email'], $_POST['password'])) {
            throw new Exception("All fields are required: username, email, and password.");
        }

        // Retrieve form data
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        // Validate that no field is empty after trimming
        if (empty($username) || empty($email) || empty($password)) {
            throw new Exception("All fields are required: username, email, and password.");
        }

        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format.");
        }

        // Check database connection
        if (!$conn) {
            throw new Exception("Database connection error: " . mysqli_connect_error());
        }

        // Insert data into the user_signup table
        $insertSignupQuery = "INSERT INTO user_signup (username, email, password) VALUES (?, ?, ?)";
        $insertSignupStmt = $conn->prepare($insertSignupQuery);

        if (!$insertSignupStmt) {
            throw new Exception("SQL prepare failed: " . $conn->error);
        }

        $insertSignupStmt->bind_param("sss", $username, $email, $password);

        if (!$insertSignupStmt->execute()) {
            throw new Exception("Database error: " . $insertSignupStmt->error);
        }

        // Insert data into the user_detail table
        $insertDetailQuery = "INSERT INTO user_detail (username, password) VALUES (?, ?)";
        $insertDetailStmt = $conn->prepare($insertDetailQuery);

        if (!$insertDetailStmt) {
            throw new Exception("SQL prepare failed: " . $conn->error);
        }

        $insertDetailStmt->bind_param("ss", $username, $password);

        if (!$insertDetailStmt->execute()) {
            throw new Exception("Database error: " . $insertDetailStmt->error);
        }

        // Prepare success response with the required format
        $response = array(
            'status' => true,
            'message' => 'Signup successful and data added to both tables',
            'data' => array(
                array(
                    'username' => $username,
                    'email' => $email,
                    'password' => $password
                )
            )
        );

        // Close prepared statements
        $insertSignupStmt->close();
        $insertDetailStmt->close();
        $conn->close();

        // Send the response
        http_response_code(200);
        echo json_encode($response, JSON_PRETTY_PRINT);

    } catch (Exception $e) {
        // Handle errors
        $response = array(
            'status' => false,
            'message' => 'Server Error: ' . $e->getMessage(),
            'data' => []
        );

        http_response_code(400);
        echo json_encode($response, JSON_PRETTY_PRINT);
    }
} else {
    // Handle unsupported HTTP methods
    $response = array(
        'status' => false,
        'message' => $RequestMethod . ' Method Not Allowed',
        'data' => []
    );

    http_response_code(405);
    echo json_encode($response, JSON_PRETTY_PRINT);
}
?>
