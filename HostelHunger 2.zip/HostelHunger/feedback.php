<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file (optional, not using in this case)
// include 'config.php'; // Uncomment if using DB connection

$RequestMethod = $_SERVER["REQUEST_METHOD"];

if ($RequestMethod == "POST") {
    try {
        // Get input data from the POST request
        $feedback = $_POST['feedback'] ?? '';

        // Validate input
        if (empty($feedback)) {
            throw new Exception("Feedback is required");
        }

        // Store feedback in session or temporary storage (e.g., array, file)
        session_start();  // Start the session to store feedback temporarily
        if (!isset($_SESSION['feedbacks'])) {
            $_SESSION['feedbacks'] = [];
        }

        // Save the feedback to the session
        $_SESSION['feedbacks'][] = [
            'feedback' => $feedback
        ];

        // Respond with success message
        $response = array(
            'status' => true,
            'message' => 'Feedback submitted successfully',
            'data' => $_SESSION['feedbacks'] // Include stored feedback in response (optional)
        );

        http_response_code(200);  // OK
        echo json_encode($response);

    } catch (Exception $e) {
        // Response on error
        $response = array(
            'status' => false,
            'message' => 'Server Error: ' . $e->getMessage(),
            'data' => []
        );

        http_response_code(500);  // Internal Server Error
        echo json_encode($response);
    }
} else {
    // Response for unsupported methods
    $response = array(
        'status' => false,
        'message' => $RequestMethod . ' Method Not Allowed',
        'data' => []
    );

    http_response_code(405);  // Method Not Allowed
    echo json_encode($response);
}
?>
