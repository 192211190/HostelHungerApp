<?php
// Include the database connection
include('config.php');
session_start();  // Start the session to access user details

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You must be logged in to change your password.");
}

// Get data from the form
$old_password = $_POST['old_password'] ?? '';
$new_password = $_POST['new_password'] ?? '';
$confirm_new_password = $_POST['confirm_new_password'] ?? '';
$user_id = $_SESSION['user_id'];  // User ID from the session

// Validate form data
if (empty($old_password) || empty($new_password) || empty($confirm_new_password)) {
    die("All fields are required.");
}

// Check if the new password and confirm new password match
if ($new_password !== $confirm_new_password) {
    die("New password and confirm new password do not match.");
}

// Fetch the current password from the user_detail table
$sql = "SELECT password FROM user_detail WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("User not found in user_detail table.");
}

$row = $result->fetch_assoc();

// Verify if the old password is correct
if (!password_verify($old_password, $row['password'])) {
    die("Old password is incorrect.");
}

// Hash the new password before updating it
$hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);

// Update the password in the user_detail table
$update_user_detail_sql = "UPDATE user_detail SET password = ? WHERE user_id = ?";
$update_user_detail_stmt = $conn->prepare($update_user_detail_sql);
$update_user_detail_stmt->bind_param("si", $hashed_new_password, $user_id);

if (!$update_user_detail_stmt->execute()) {
    die("Error updating password in user_detail: " . $conn->error);
}

// Fetch the current password from the changePassword table
$changePassword_sql = "SELECT password FROM changePassword WHERE user_id = ?";
$changePassword_stmt = $conn->prepare($changePassword_sql);
$changePassword_stmt->bind_param("i", $user_id);
$changePassword_stmt->execute();
$changePassword_result = $changePassword_stmt->get_result();

if ($changePassword_result->num_rows == 0) {
    die("User not found in changePassword table.");
}

$changePassword_row = $changePassword_result->fetch_assoc();

// Verify if the old password matches in the changePassword table
if (password_verify($old_password, $changePassword_row['password'])) {
    // Update the password in the changePassword table
    $update_changePassword_sql = "UPDATE changePassword SET password = ? WHERE user_id = ?";
    $update_changePassword_stmt = $conn->prepare($update_changePassword_sql);
    $update_changePassword_stmt->bind_param("si", $hashed_new_password, $user_id);

    if (!$update_changePassword_stmt->execute()) {
        die("Error updating password in changePassword table: " . $conn->error);
    }
}

echo "Password updated successfully in both user_detail and changePassword tables.";

// Close the connection
$conn->close();
?>
