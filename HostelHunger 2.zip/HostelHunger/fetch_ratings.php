<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Include the database connection file
include 'config.php';

$RequestMethod = $_SERVER["REQUEST_METHOD"];

if ($RequestMethod == "GET") {
    try {
        // Check if food_id is provided
        if (isset($_GET['food_id'])) {
            $food_id = intval($_GET['food_id']); // Ensure it's an integer

            // Prepare and execute the query
            $stmt = $conn->prepare("SELECT * FROM ratings WHERE food_id = ?");
            $stmt->bind_param("i", $food_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $ratings = $result->fetch_all(MYSQLI_ASSOC);

            // Respond with the results
            echo json_encode([
                'success' => true,
                'data' => $ratings
            ]);
        } else {
            // If food_id is not provided
            echo json_encode([
                'success' => false,
                'message' => 'food_id parameter is required'
            ]);
        }
    } catch (Exception $e) {
        // Handle database errors
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    // Handle invalid request methods
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method. Use GET.'
    ]);
}
?>
