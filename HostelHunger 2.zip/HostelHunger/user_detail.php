<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file
include 'config.php';

$RequestMethod = $_SERVER["REQUEST_METHOD"];

if ($RequestMethod == "POST") {
    try {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';

        // Validate inputs
        if (empty($username) || empty($password)) {
            throw new Exception("Username and password are required");
        }

        // Check if the user exists
        $checkQuery = "SELECT * FROM user_detail WHERE username = ? AND password = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("ss", $username, $password);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            // If the user exists, respond with a success message including password
            $response = array(
                'status' => true,
                'message' => 'Login successful',
                'data' => array(
                    array(
                        'username' => $username,
                        'password' => $password // Including password in response
                    )
                )
            );
            http_response_code(200);
            // echo json_encode($response);
        } else {
            // If the user does not exist, respond with an error message
            $response = array(
                'status' => false,
                'message' => 'Invalid username or password',
                'data' => []
            );
            http_response_code(401); // Unauthorized
            // echo json_encode($response);
        }

        // Close the statement and connection
        $checkStmt->close();
        $conn->close();

        echo json_encode($response);
    } catch (Exception $e) {
        // Response on error
        $response = array(
            'status' => false,
            'message' => 'Server Error: ' . $e->getMessage(),
            'data' => []
        );

        http_response_code(500);
        echo json_encode($response);
    }
} else {
    // Response for unsupported methods
    $response = array(
        'status' => false,
        'message' => $RequestMethod . ' Method Not Allowed',
        'data' => []
    );

    http_response_code(405);
    echo json_encode($response);
}
?>