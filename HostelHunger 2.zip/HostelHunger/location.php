<?php
// Include the database configuration file
include('config.php');

// Prepare the response array
$response = array();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the location is provided
    if (!empty($_POST['location'])) {
        // Get the location data
        $location = $_POST['location'];

        // Check if the connection is successful
        if ($conn->connect_error) {
            $response['status'] = 'error';
            $response['message'] = 'Connection failed: ' . $conn->connect_error;
            echo json_encode($response);
            exit();
        }

        // Escape the value to prevent SQL injection
        $location = $conn->real_escape_string($location);

        // Prepare the SQL query to insert the data into the `location` table
        $sql = "INSERT INTO location (location) VALUES ('$location')";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            // Get the last inserted ID (auto-incremented id)
            $last_id = $conn->insert_id;
            $response['status'] = 'success';
            $response['message'] = 'Location added successfully.';
            $response['data'] = [
                [
                    'id' => $last_id,
                    'location' => $location
                ]
            ];
        } else {
            // Return an error message if the query fails
            $response['status'] = 'error';
            $response['message'] = 'Error adding location: ' . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        // If the location is not provided
        $response['status'] = 'error';
        $response['message'] = 'Please provide a location.';
    }
} else {
    // If the request method is not POST
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method. Please use POST.';
}

// Return the response as JSON
echo json_encode($response);
?>
