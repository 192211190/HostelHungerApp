<?php
// Enable CORS and set response headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file
include 'config.php';

$RequestMethod = $_SERVER["REQUEST_METHOD"];

// Handle preflight requests for CORS
if ($RequestMethod === "OPTIONS") {
    http_response_code(200);
    exit;
}

try {
    // Validate database connection
    if (!$conn) {
        throw new Exception("Database connection failed: " . mysqli_connect_error());
    }

    if ($RequestMethod == "GET") {
        // Fetch all data from the nonVeglist table
        $sql = "SELECT image, food_name FROM nonVeglist";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $data = [];
            while ($row = $result->fetch_assoc()) {
                // Map the database fields to desired structure
                $data[] = [
                    'image' => $row['image'],
                    'food_name' => $row['food_name']
                ];
            }

            // Success response
            $response = [
                'status' => true,
                'message' => 'Successfully fetched',
                'data' => $data
            ];
        } else {
            // No data found
            $response = [
                'status' => false,
                'message' => 'No records available in the database.',
                'data' => []
            ];
        }
    } else {
        // Handle invalid HTTP methods (i.e., anything other than GET)
        $response = [
            'status' => false,
            'message' => $RequestMethod . ' Method Not Allowed',
            'data' => [] // Return an empty array for consistency
        ];

        http_response_code(405);
    }

    // Send the response in JSON format
    echo json_encode($response);

    // Close the database connection
    $conn->close();
} catch (Exception $e) {
    // Handle any exceptions and send a 500 server error response
    $response = [
        'status' => false,
        'message' => $e->getMessage(),
        'data' => [] // Return an empty array for consistency
    ];

    http_response_code(500);
    echo json_encode($response);
}
?>
