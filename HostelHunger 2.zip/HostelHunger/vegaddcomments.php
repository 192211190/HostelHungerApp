<?php
// Include the database configuration file
include('config.php');

// Prepare the response array
$response = array();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the POST request has the 'comment' field
    if (isset($_POST['comment'])) {
        // Get the comment data
        $comment = $_POST['comment'] ?: '';  // Set to empty string if not provided

        // Check if the connection is successful
        if ($conn->connect_error) {
            echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
            exit();
        }

        // Escape the comment value to prevent SQL injection
        $comment = $conn->real_escape_string($comment);

        // Prepare the SQL query to insert the data into the `vegRest` table
        $sql = "INSERT INTO vegRest (comment) VALUES ('$comment')";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            // Success response
            $response = [
                "status" => "success",
                "message" => "Comment added successfully.",
                "data" => [
                    ["comment" => $comment]
                ]
            ];
        } else {
            $response = [
                "status" => "error",
                "message" => "Error inserting comment: " . $conn->error
            ];
        }

        // Close the database connection
        $conn->close();
    } else {
        // If comment field is missing
        $response = [
            "status" => "error",
            "message" => "Please provide a comment."
        ];
    }
} else {
    // If the request method is not POST
    $response = [
        "status" => "error",
        "message" => "Invalid request method. Please use POST."
    ];
}

// Return the response as JSON
echo json_encode($response);
?>
