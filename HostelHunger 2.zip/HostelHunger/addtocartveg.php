<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Include the database connection file
include 'config.php';

$RequestMethod = $_SERVER["REQUEST_METHOD"];

if ($RequestMethod == "GET") {
    try {
        // Check if food_id is provided
        if (isset($_GET['food_id']) && strlen(trim($_GET['food_id'])) > 0) {
            $food_id = intval($_GET['food_id']); // Convert food_id to an integer

            // Check database connection
            if ($conn) {
                // Prepare and execute the query
                $stmt = $conn->prepare("SELECT foodname, restaurant_name, amount FROM vegList WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param("i", $food_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result) {
                        $data = $result->fetch_assoc(); // Fetch the single result

                        if ($data) {
                            // Wrap the result in an array
                            echo json_encode([
                                'success' => true,
                                'data' => [$data] // Ensure data is an array
                            ]);
                        } else {
                            // If no data found for the provided food_id
                            echo json_encode([
                                'success' => false,
                                'message' => 'No data found for the provided food_id.'
                            ]);
                        }
                    } else {
                        echo json_encode([
                            'success' => false,
                            'message' => 'Error fetching results from the database.'
                        ]);
                    }
                    $stmt->close();
                } else {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Failed to prepare the SQL statement. Error: ' . $conn->error
                    ]);
                }
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Database connection failed: ' . $conn->connect_error
                ]);
            }
        } else {
            // If the food_id is missing or empty
            echo json_encode([
                'success' => false,
                'message' => 'The food_id parameter is required and cannot be empty.'
            ]);
        }
    } catch (Exception $e) {
        // Handle database errors
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
} else {
    // Handle invalid request methods
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method. Use GET.'
    ]);
}
?>
