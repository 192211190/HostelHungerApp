<?php
// Include the database configuration file
include('config.php');

// Prepare the response array
$response = array();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if restaurant_name and available_status are provided
    if (!empty($_POST['restaurant_name']) && !empty($_POST['available_status'])) {
        // Get the restaurant data
        $restaurant_name = $_POST['restaurant_name'];
        $available_status = $_POST['available_status'];

        // Check if the connection is successful
        if ($conn->connect_error) {
            $response['status'] = 'error';
            $response['message'] = 'Connection failed: ' . $conn->connect_error;
            echo json_encode($response);
            exit();
        }

        // Escape the values to prevent SQL injection
        $restaurant_name = $conn->real_escape_string($restaurant_name);
        $available_status = $conn->real_escape_string($available_status);

        // Prepare the SQL query to insert the data into the `list_of_rest` table
        $sql = "INSERT INTO list_of_rest (restaurant_name, available_status) VALUES ('$restaurant_name', '$available_status')";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            // Get the last inserted ID (auto-incremented id)
            $last_id = $conn->insert_id;
            $response['status'] = 'success';
            $response['message'] = 'Restaurant added successfully.';
            $response['data'] = [
                [
                    'id' => $last_id,
                    'restaurant_name' => $restaurant_name,
                    'available_status' => $available_status
                ]
            ];
        } else {
            // Return an error message if the query fails
            $response['status'] = 'error';
            $response['message'] = 'Error adding restaurant: ' . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        // If the required fields are not provided
        $response['status'] = 'error';
        $response['message'] = 'Please provide both restaurant_name and available_status.';
    }
} else {
    // If the request method is not POST
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method. Please use POST.';
}

// Return the response as JSON
echo json_encode($response);
?>
