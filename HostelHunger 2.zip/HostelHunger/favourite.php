<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file
include 'config.php';

$RequestMethod = $_SERVER["REQUEST_METHOD"];

if ($RequestMethod == "POST") {
    try {
        $food_name = $_POST['food_name'] ?? '';

        // Validate input
        if (empty($food_name)) {
            throw new Exception("Food name is required.");
        }

        // Check if the item exists in the database
        $checkQuery = "SELECT * FROM items WHERE food_name = ?";
        $checkStmt = $conn->prepare($checkQuery);

        if (!$checkStmt) {
            throw new Exception("SQL prepare failed: " . $conn->error);
        }

        $checkStmt->bind_param("s", $food_name);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            // Add the item to the popular list
            $updateQuery = "UPDATE items SET is_popular = 1 WHERE food_name = ?";
            $updateStmt = $conn->prepare($updateQuery);

            if (!$updateStmt) {
                throw new Exception("SQL prepare failed: " . $conn->error);
            }

            $updateStmt->bind_param("s", $food_name);

            if ($updateStmt->execute()) {
                $response = array(
                    'status' => true,
                    'message' => 'Item added to popular list successfully.',
                    'data' => array(
                        'food_name' => $food_name
                    )
                );
            } else {
                throw new Exception("Database error: " . $updateStmt->error);
            }

            $updateStmt->close();
        } else {
            throw new Exception("Item with food name " . $food_name . " not found.");
        }

        // Close the check statement and connection
        $checkStmt->close();
        $conn->close();

        http_response_code(200);
        echo json_encode($response);
    } catch (Exception $e) {
        // Response on error
        $response = array(
            'status' => false,
            'message' => 'Server Error: ' . $e->getMessage(),
            'data' => []
        );

        http_response_code(500);
        echo json_encode($response);
    }
} else {
    // Response for unsupported methods
    $response = array(
        'status' => false,
        'message' => $RequestMethod . ' Method Not Allowed',
        'data' => []
    );

    http_response_code(405);
    echo json_encode($response);
}
?>
