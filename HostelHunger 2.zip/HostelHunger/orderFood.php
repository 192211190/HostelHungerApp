<?php
// Include the database configuration file
include('config.php');

// Check if the form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the POST request
    $user_id = $_POST['user_id'];    // User ID
    $user_name = $_POST['user_name'];    // User Name
    $foodname = $_POST['foodname'];    // Food Name
    $image = $_POST['image'];    // Food Image (URL or path)
    $quantity = $_POST['quantity'];    // Quantity of food items
    $ordertype = $_POST['ordertype'];    // Order type (e.g., dine-in, takeaway)

    // Check if all required fields are filled
    if (!empty($user_id) && !empty($user_name) && !empty($foodname) && !empty($image) && !empty($quantity) && !empty($ordertype)) {
        // Prepare an SQL query to insert the data into the "payOrder" table
        $sql = "INSERT INTO payOrder (user_id, user_name, foodname, image, quantity, ordertype) 
                VALUES (?, ?, ?, ?, ?, ?)";

        // Prepare the statement
        if ($stmt = $conn->prepare($sql)) {
            // Bind parameters to the query
            $stmt->bind_param("isssis", $user_id, $user_name, $foodname, $image, $quantity, $ordertype);

            // Execute the query
            if ($stmt->execute()) {
                // Success response
                $response = array("status" => "success", "message" => "Order placed successfully.");
            } else {
                // Error executing query, capture error
                $response = array("status" => "error", "message" => "Failed to place the order. SQL Error: " . $stmt->error);
            }

            // Close the statement
            $stmt->close();
        } else {
            // Error preparing the query, capture error
            $response = array("status" => "error", "message" => "Failed to prepare the SQL statement. MySQL Error: " . $conn->error);
        }
    } else {
        // Missing fields in the request
        $response = array("status" => "error", "message" => "Please fill in all fields.");
    }
} else {
    // Invalid request method
    $response = array("status" => "error", "message" => "Invalid request method.");
}

// Close the connection
$conn->close();

// Return the response as JSON
echo json_encode($response);
?>
