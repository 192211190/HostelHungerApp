<?php
// Include the database configuration
require 'config.php';

// Query to fetch data
$sql = "SELECT id, amount FROM available_amount";

$response = ["status" => "success", "data" => []]; // Initialize the response array

try {
    $result = $conn->query($sql);

    if ($result === false) {
        throw new Exception("Query failed: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        // Fetch and append each row to the data array
        while ($row = $result->fetch_assoc()) {
            $response["data"][] = [
                "id" => $row['id'],
                "amount" => $row['amount']
            ];
        }
    } else {
        $response["data"] = [];
    }
} catch (Exception $e) {
    // Handle errors
    $response = ["status" => "error", "message" => $e->getMessage()];
}

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response, JSON_PRETTY_PRINT);

// Close the connection
$conn->close();
?>
