<?php
// config.php

// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "HostelHunger";

try {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    // Handle connection errors
    die("Database connection error: " . $e->getMessage());
}

// $conn is now ready for use
?>
