<?php
// Include the database configuration file
include('config.php');

// Prepare the response array
$response = array();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the POST request has both name and price
    if (isset($_POST['name']) && isset($_POST['price'])) {
        // Get the item data
        $name = $_POST['name'] ?: '';  // Set to empty string if not provided
        $price = $_POST['price'] ?: '';  // Set to empty string if not provided

        // Check if the connection is successful
        if ($conn->connect_error) {
            echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
            exit();
        }

        // Escape the values to prevent SQL injection
        $name = $conn->real_escape_string($name);
        $price = $conn->real_escape_string($price);

        // Prepare the SQL query to insert the data into the `updatemenu` table
        $sql = "INSERT INTO updatemenu (name, price) VALUES ('$name', '$price')";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            // Get the last inserted ID (auto-incremented id)
            $last_id = $conn->insert_id;
            $response['status'] = 'success';
            $response['message'] = 'Item added successfully.';
            $response['id'] = $last_id;  // Return the last inserted ID
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error inserting item: ' . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        // If required fields are missing
        $response['status'] = 'error';
        $response['message'] = 'Please provide name and price.';
    }
} else {
    // If the request method is not POST
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method. Please use POST.';
}

// Return the response as JSON
echo json_encode($response);
?>
