<?php
// Set the Content-Type to JSON
header('Content-Type: application/json');

// Include database configuration
include 'config.php';

// Prepare the response array
$response = array();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set in the POST request
    if (isset($_POST['name']) && isset($_POST['price']) && isset($_FILES['image'])) {
        $name = $_POST['name'];
        $price = $_POST['price'];
        $imageName = '';  // Default value for image name

        // Check if the connection is successful
        if ($conn->connect_error) {
            echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
            exit();
        }

        // Escape the values to prevent SQL injection
        $name = $conn->real_escape_string($name);
        $price = $conn->real_escape_string($price);

        // Handle image upload
        $image = $_FILES['image'];

        // Check for upload errors
        if ($image['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(["status" => "error", "message" => "File upload error: " . $image['error']]);
            exit();
        }

        // Validate image type (optional, adjust as needed)
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($image['type'], $allowedTypes)) {
            echo json_encode(["status" => "error", "message" => "Invalid image type. Only JPG, PNG, and GIF are allowed."]);
            exit();
        }

        // Validate image size (optional, adjust as needed)
        if ($image['size'] > 5000000) { // 5MB limit
            echo json_encode(["status" => "error", "message" => "Image size exceeds the 5MB limit."]);
            exit();
        }

        // Set the directory where the image will be uploaded
        $targetDir = "uploads/";

        // Check if the directory exists, if not, create it
        if (!is_dir($targetDir)) {
            if (!mkdir($targetDir, 0777, true)) {
                echo json_encode(["status" => "error", "message" => "Failed to create directory: " . $targetDir]);
                exit();
            }
        }

        // Get the image file name and add a unique timestamp to it
        $imageName = uniqid(time() . "_", true) . "_" . basename($image["name"]);
        $targetFile = $targetDir . $imageName;

        // Try moving the uploaded file
        if (!move_uploaded_file($image["tmp_name"], $targetFile)) {
            echo json_encode(["status" => "error", "message" => "Error uploading image."]);
            exit();
        }

        // Prepare the SQL query to insert the data into the `todaysmenu` table
        $sql = "INSERT INTO todaysmenu (name, price, image) VALUES ('$name', '$price', '$imageName')";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            // Get the last inserted ID (auto-incremented id)
            $last_id = $conn->insert_id;
            $response['status'] = 'success';
            $response['message'] = 'Menu item added successfully.';
            $response['id'] = $last_id;  // Return the last inserted ID
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error inserting item: ' . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        // If required fields or files are missing
        $response['status'] = 'error';
        $response['message'] = 'Please provide name, price, and an image.';
    }
} else {
    // If the request method is not POST
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method. Please use POST.';
}

// Return the response as JSON
echo json_encode($response);
?>
