<?php
// Include the database configuration file
include('config.php');

// Prepare the response array
$response = array();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the POST request has the 'comments' field
    if (isset($_POST['comments'])) {
        // Get the comments data
        $comments = $_POST['comments'] ?: '';  // Set to empty string if not provided

        // Check if the connection is successful
        if ($conn->connect_error) {
            echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
            exit();
        }

        // Escape the comments value to prevent SQL injection
        $comments = $conn->real_escape_string($comments);

        // Prepare the SQL query to insert the data into the `items` table
        $sql = "INSERT INTO items (comments) VALUES ('$comments')";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            // Success response
            $response = [
                "status" => "success",
                "message" => "Comment added successfully.",
                "data" => [
                    ["comment" => $comments]
                ]
            ];
        } else {
            $response = [
                "status" => "error",
                "message" => "Error inserting comment: " . $conn->error
            ];
        }

        // Close the database connection
        $conn->close();
    } else {
        // If comments field is missing
        $response = [
            "status" => "error",
            "message" => "Please provide a comment."
        ];
    }
} else {
    // If the request method is not POST
    $response = [
        "status" => "error",
        "message" => "Invalid request method. Please use POST."
    ];
}

// Return the response as JSON
echo json_encode($response);
?>
