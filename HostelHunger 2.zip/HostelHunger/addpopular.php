<?php
// Include the database configuration
require 'config.php';

// Initialize response array
$response = [
    "status" => "error", 
    "message" => "An error occurred.",
    "data" => []
];

// Check if data is sent via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $popular = $_POST['popular'] ?? null;

    try {
        // Validate inputs
        if (empty($popular)) {
            throw new Exception("The 'popular' field is required.");
        }

        // Insert data into the table (let MySQL auto-increment the 'id')
        $stmt = $conn->prepare("INSERT INTO adminmenu (popular) VALUES (?)");
        $stmt->bind_param("s", $popular);

        if ($stmt->execute()) {
            // Get the last inserted ID
            $last_id = $conn->insert_id;

            // Prepare response data
            $response["status"] = "success";
            $response["message"] = "Item added successfully.";
            $response["data"] = [
                [
                    "id" => (string)$last_id,  // Ensure the ID is a string
                    "popular" => $popular
                ]
            ];
        } else {
            throw new Exception("Failed to add data: " . $stmt->error);
        }

        $stmt->close();
    } catch (Exception $e) {
        // In case of error, set the error message in response
        $response["message"] = $e->getMessage();
    }
}

// Close the connection
$conn->close();

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response, JSON_PRETTY_PRINT);
?>
